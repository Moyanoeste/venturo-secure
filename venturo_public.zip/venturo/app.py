from flask import Flask, jsonify, request

app = Flask(__name__)

PROJECT_NAME = "Venturo"

MODULES = [
    {
        "id": 1,
        "name": "Orientación empresarial",
        "description": "Ayuda práctica para estructurar y desarrollar una idea de negocio."
    },
    {
        "id": 2,
        "name": "Fiscalidad",
        "description": "Información y orientación sobre obligaciones fiscales para pequeños negocios."
    },
    {
        "id": 3,
        "name": "Aspectos legales",
        "description": "Orientación sobre cuestiones legales habituales al iniciar una actividad."
    },
    {
        "id": 4,
        "name": "Formación",
        "description": "Planes de aprendizaje adaptados al proyecto y al nivel del usuario."
    }
]


@app.route("/")
def home():
    return jsonify({
        "application": PROJECT_NAME,
        "status": "development",
        "description": "Asistente inteligente para emprendedores y pequeñas empresas.",
        "modules": len(MODULES)
    })


@app.route("/api/modules", methods=["GET"])
def get_modules():
    return jsonify({"modules": MODULES})


@app.route("/api/business/analyze", methods=["POST"])
def analyze_business():
    data = request.get_json(silent=True) or {}

    business_name = data.get("business_name", "").strip()
    business_type = data.get("business_type", "").strip()

    if not business_name or not business_type:
        return jsonify({
            "error": "business_name y business_type son obligatorios"
        }), 400

    recommendations = [
        "Definir claramente el modelo de negocio.",
        "Identificar las obligaciones fiscales aplicables.",
        "Revisar los requisitos legales de la actividad.",
        "Crear un plan de formación y seguimiento."
    ]

    return jsonify({
        "business": business_name,
        "type": business_type,
        "recommendations": recommendations
    })


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)

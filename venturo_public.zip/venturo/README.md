# Venturo

Venturo is an early-stage intelligent assistant designed to help entrepreneurs and small businesses with practical business guidance.

## What it addresses

Starting and managing a small business often requires understanding multiple areas at once. Venturo aims to bring practical guidance into one accessible platform.

The project explores:

- Business planning
- Fiscal orientation
- Legal guidance
- Training and learning plans
- AI-assisted support

## Current status

Venturo is currently under development and validation. This public repository contains a lightweight demonstration of the project's API and core concept. Production components and private development work are intentionally not included.

## Running locally

```bash
python -m venv .venv
```

Activate the environment and install dependencies:

```bash
pip install -r requirements.txt
```

Then run:

```bash
python app.py
```

The API will be available at:

`http://127.0.0.1:5000`

## Example

GET `/api/modules`

POST `/api/business/analyze`

Example request:

```json
{
  "business_name": "Example Business",
  "business_type": "Retail"
}
```

## Security

This public demonstration contains no API keys, passwords, real user data, or production credentials.

## License

No open-source license is currently applied. All rights reserved.
